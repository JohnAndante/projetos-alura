// Variáveis de imagens
let bgFreeway;
let imgPlayer;
let imgCar01;
let imgCar02;
let imaCar03;

function preload(){
  bgFreeway = loadImage("images/estrada.png");
  imgPlayer = loadImage("images/ator-1.png");
  imgCar01 = loadImage("images/carro-1.png");
  imgCar02 = loadImage("images/carro-2.png");
  imgCar03 = loadImage("images/carro-3.png");
  imgCars = [imgCar01, imgCar02, imgCar03];
}